
public class HAGAG {

	public HAGAG() {
		// TODO Auto-generated constructor stub
	}

}
