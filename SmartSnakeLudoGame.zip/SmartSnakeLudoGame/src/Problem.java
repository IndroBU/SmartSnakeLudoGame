
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;

@SuppressWarnings("serial")
public class Problem extends JPanel {
    private static final int SIDES = 8;
    private static final int GAP = 15;
    public static final Color HOVER_COLOR = Color.pink;
    private List<JLabel> labels = new ArrayList<>();

    public Problem() {
        setLayout(new GridLayout(SIDES, SIDES));
        MyMouseHandler myMouseHandler = new MyMouseHandler();
        for (int i = 0; i < SIDES * SIDES; i++) {
            String text = String.format("[%d, %d]", i % SIDES + 1, i / SIDES + 1);
            JLabel label = new JLabel(text);
            label.setOpaque(true);
            label.setBorder(BorderFactory.createEmptyBorder(GAP, GAP, GAP, GAP));
            label.addMouseListener(myMouseHandler);
            labels.add(label);
            add(label);
        }
    }

    private class MyMouseHandler extends MouseAdapter {
        @Override
        public void mouseEntered(MouseEvent evt) {
            JLabel source = (JLabel) evt.getSource();
            for (JLabel label : labels) {
                if (label == source) {
                    label.setBackground(HOVER_COLOR);
                } else {
                    label.setBackground(null);
                }
            }
        }

    }

    private static void createAndShowGui() {
        Problem mainPanel = new Problem();

        JFrame frame = new JFrame("ManyLabelExample");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.getContentPane().add(mainPanel);
        frame.pack();
        frame.setLocationByPlatform(true);
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                createAndShowGui();
            }
        });
    }
}
